const sdk = require('@salesforce/salesforce-sdk');
import { UnitOfWork, SObject } from '@salesforce/functions';

/*
 * Describe PushMobile here.
 *
 * The exported method is the entry point for your code when the function is invoked. 
 *
 * Following parameters are pre-configured and provided to your function on execution: 
 * @param event:   represents the data associated with the occurrence of an event, and  
 *                 supporting metadata about the source of that occurrence.
 * @param context: represents the connection to Evergreen and your Salesforce org.
 * @param logger:  logging handler used to capture application logs and traces specific  
 *                 to a given execution of a function.
 */
 
 /*
	Since the Salesforce evergreen functions could not be tested, the code here represents the way to call/invoke a push notification. 
 */
module.exports = function (event, context, logger) {
    logger.info(`Invoking PushMobile with payload ${JSON.stringify(event.data || {})}`);
	
	/*
		The event paylod's JSON structure is as follows: 
		
		{
		  "data": {
			"schema": "dffQ2QLzDNHqwB8_sHMxdA", 
			"payload": {
			  "UserIds": "005D0000001cSZs, 005D0000001cSZs, 005D0000001cSZs, 005D0000001cSZs", 
			  "BusTripNumber": "ABC-MUM-PUN-18052020", 
			  "Status": "Cancelled",
			  "customNotifId" : "ANND0000001cSH6",
			  "message" : "We regret to inform you that the trip has been cancelled. Pleae be rest assured that the amount will refunded within 7 business days. Apologize for the inconvenience"
			  "URL" : "https://busreservation.lightning.force.com/"
			}, 
			"event": {
			  "replayId": 2
			}
		  }, 
		  "channel": "/event/Push_Cancellation__e"
		}
	*/
	
	var payload = event.data.payload;
	
	//Rest call for mobile push notification
	
	Http h = new Http();
    HttpRequest req = new HttpRequest();
    req.setEndpoint(payload.URL + '/services/data/v46.0/actions/standard/customNotificationAction');
    req.setMethod('POST');
    req.setHeader('Authorization', 'Bearer ' + context.bearertoken)); //This is equivalent to the value retured when sfdx evergreen:auth:bearer is run
    req.setHeader('Content-Type', 'application/json');
    CustomNotificationActionInput input = new SObject('CustomNotificationActionInput');
    input.customNotifTypeId = payload.customNotifId;
    input.recipientIds = new List<String>{payload.UserIds};
    input.title = 'Trip: ' + payload.BusTripNumber + ' has been cancelled';
    input.body = payload.message;
    CustomNotificationAction action = new SObject('CustomNotificationAction');
    action.inputs = new List<CustomNotificationActionInput>{input};
    req.setBody(JSON.serialize(action));
    HttpResponse res = h.send(req);
    	
}
